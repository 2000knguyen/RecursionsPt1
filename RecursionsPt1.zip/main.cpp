/*
Name: Kendrick Nguyen
Date: 16 Feburary 2021
*/
#include <math.h> 
#include <iostream>
using namespace std;


/*Finds the result of base raised to result of exponent
 * @param base the base value
 * @param exp the exponent
 * @return the result of the base raised to the exponent
 * Talked to profess about how we cannot use an if statement that has (exp!=0)
 * Would cause an overflow if the test number given was -1
 */
int power( int base, int exp ) {
  if (exp > 0){
    return (base * power(base, exp - 1));
  }else{
    return 1;
  }
}

/*Tests the number to see if it is prime
 * @param num the number to test is prime
 * @param count the divisor to divide by (initialize at n-1)
 * @return  true if prime, false otherwise
 * Essentially, the function makes it way through the count to 0 and then returns true
 * If at any point the mod returns 0, it would mean that the number is not prime
 */
bool isPrime( int num, int count ) {
  if(count == 1){
    return true;
  }else if(num % count == 0){
    return false;
  }
  return isPrime(num, count-1);
}

/*Finds the number of  digits in num
 * @param num value to find the number of digits of itself, i.e. amount of digits in 987412
 * @return the number of digits for inputs that are more than 0
 * Was given to us in the lab hint
 * Talked to profess about how we cannot use an if statement that has (num!=0)
 * Would cause an overflow if the test number given was -1
 */
int countDigits( int num ) {
  if(num > 0){
    return 1 + countDigits(num / 10);
  }else{
    return 0;
  }
}

// Main function used to check if the other functions were done right
// DO not change any of code in here
int main() {
	if(power(2,3) == 8) {
		cout << "1. power1 is correct!" << endl;
	}
	if(power(5,7) == 78125) {
		cout << "2. power2 is correct!" << endl;
	}
  	if(isPrime(7, 6)) {
		cout << "3. isPrime1 is correct!" << endl;
	}
	if(!isPrime(10, 9)) {
		cout << "4. isPrime2 is correct!" << endl;
	}	
  	if(countDigits(4) == 1) {
		cout << "5. countDigits1 is correct!" << endl;
	}
	if(countDigits(987412) == 6) {
		cout << "6. countDigits2 is correct!" << endl;
	}
}